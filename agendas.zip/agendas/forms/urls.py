from django.urls import path
from .views import*


urlpatterns = [
    path('', home, name='home'),
    path('formulario', formulario, name='formulario'),
    path('home', home, name='home'),
    path('listado', listado, name='listado'),
    path('eliminar/<int:id>',eliminar, name='eliminar'),
    path('editar/<pk>', ContactoUpdate.as_view(), name='editar'),
    #path('editar/<int:id>',editar, name='editar'),
    path('reporte', reporte, name='reporte')

]


   

