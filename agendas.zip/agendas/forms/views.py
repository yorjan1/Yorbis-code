from django.shortcuts import render, redirect


from django.http import HttpResponse
from django.views.generic import *
from django.urls import reverse_lazy

from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle, Image

from io import BytesIO


from .forms import *
from .models import *

# Create your views here.
def home(request):
	return render(request, 'forms/index.html')

def listado(request):
    listx = Contacto.objects.all()
    return render(request, 'forms/list.html', {"listx": listx})

def formulario(request):
    if request.method == 'POST': # si la persona está enviando el formulario con datos
        form = ContactoForm(request.POST, request.FILES) # Bound form
        if form.is_valid():
            Contacto = form.save() # Guardar los datos en la base de datos
            return redirect ('home') 
    form = ContactoForm() # Unbound form
    return render(request, 'forms/formulario.html', {'form': form})

def eliminar(request,id):
    listz = Contacto.objects.get(id=id)
    listz.delete()
    return redirect ('listado')

class ContactoUpdate(UpdateView):
    model = Contacto
    form_class = ContactoForm
    template_name = 'forms/formulario.html'
    context_object_name = 'obj'
    success_url =reverse_lazy('form:editar')

#def editar(request,id):
#    listz = Contacto.objects.get(id=id)
#    if request.method == 'GET':
#        form = ContactoForm(instance=listz)
#    else:
#        form = ContactoForm(request.POST or None, instance=listz)
#        if form.is_valid():
#           form.save()
#        return redirect('home')
#    return render(request, 'forms/formulario.html', {'form':form }) 
    
def reporte (request):
    response = HttpResponse (content_type= 'forms/pdf')
    response['Content-Disposition'] ='attachment; filename=Yorbis-reporte-report.pdf'
    buffer=BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    c.setLineWidth(.3)
    c.setFont('Helvetica', 22)
    c.drawString(30,750,'Yorbis')
    c.setFont('Helvetica-Bold',15)
    c.drawString(480,750,'01/04/2022')
    c.line(460,747,560,747)
    
    #tabla header
    styles=getSampleStyleSheet()
    styleBH=styles['Normal']
    styleBH.alignment = TA_CENTER
    styleBH.fontSize = 10

    def agraegatePerson(person):
        personx = {'#':'1'}
        personx['nombre']      = person.nombre
        personx['apellido']    = person.apellido
        personx['cedula']      = person.cedula
        personx['direccion']   = person.direccion
        personx['email']       = person.email
        personx['telefono_movil'] = person.telefono_movil
        personx['telefono_casa']  = person.telefono_casa
        return personx

    personas = list(map(agraegatePerson, Contacto.objects.all()))

    idx            = Paragraph('''id''',styleBH)
    nombre         = Paragraph('''nombre''',styleBH)
    apellido       = Paragraph('''apellido''',styleBH)
    cedula         = Paragraph('''cedula''',styleBH)
    direccion      = Paragraph('''direccion''',styleBH)
    email          = Paragraph('''email''',styleBH)
    telefono_movil = Paragraph('''telefono movil''',styleBH)
    telefono_casa  = Paragraph('''telefono casero''',styleBH)
    data=[[
            idx, nombre, apellido,
            cedula, direccion, email,
            telefono_movil, telefono_casa
        ]]

    #tabla
    styleN = styles ["BodyText"]
    styleN.alignment = TA_CENTER
    styleN.fontSize = 7
    high=650

    for p in personas:
        this_persona= [
            p['#'],        p['nombre'],
            p['apellido'], p['cedula'],
            p['direccion'],p['email'], 
            p['telefono_movil'],p['telefono_casa']
        ]
        data.append(this_persona)
        high = high - 18
    #tamaño tabla
    width, height = A4
    table = Table(
        data,
        colWidths=[
            1 * cm,   1.9 * cm,
            1.9 * cm, 1.9 * cm,
            1.9 * cm, 3.3 * cm, 
        ]
    )
    table.setStyle(TableStyle([
        ('INERGRID', (0,0), (-1,-1), 0.25, colors.black),
        ('BOX',(0,0),(-1,-1), 0.25, colors.black,)
        ]))
    table.wrapOn(c, width, height)
    table.drawOn(c, 30, high)
    c.showPage()
    c.save()
    pdf= buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response

